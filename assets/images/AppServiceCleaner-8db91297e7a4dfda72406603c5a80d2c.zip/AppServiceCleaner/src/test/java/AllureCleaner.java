import io.restassured.RestAssured;
import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicInteger;

import static io.restassured.RestAssured.given;

public class AllureCleaner {

	public void clean(String ProjectName, int yyyymmmdd) {
		AtomicInteger deletedFolderCount= new AtomicInteger();
		RestAssured.baseURI = "https://YOUR_APP_NAME.scm.azurewebsites.net/api/vfs/site/wwwroot/";
		ResponsePojo[] response = new ResponsePojo[0];
		try {
			response =
					given().
							auth().
							basic("APPSERVICE_USERNAME", "APPSERVICE_PASSWORD").
					when().
							get(ProjectName).
					then()
							.statusCode(200)
							.extract()
							.response()
							.as(ResponsePojo[].class);
		}
		catch (Exception e)
		{

		}
		System.out.println("No.Of Reports In Project: "+ProjectName+ " : " + response.length);
		Arrays.stream(response).forEach(r ->
		{
			Integer date2 = null;
			String folderName = null;
			String date = null;

			try {

				folderName = r.getName().substring(0, r.getName().length() - 10);
				date = r.getName().substring(r.getName().length() - 10);
				date2 = Integer.parseInt(date.substring(0,8));
				if (date2 < yyyymmmdd) {
					System.out.println("Deleting The Report: " + folderName + date);
					deletedFolderCount.getAndIncrement();
					given().
							queryParam("recursive", "true").
							auth().
							basic("APPSERVICE_USERNAME", "APPSERVICE_PASSWORD").
					when().
							delete(ProjectName + "/" + folderName + date).
					then()
							.statusCode(200);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		});

		System.out.println("No.Of Reports Deleted: "+deletedFolderCount);

	}

	@Test
	public void cleanReports() {

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_WEEK, -2);
		System.out.println("Date in System Running: "+calendar.getTime());
		SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMdd");
		int dateBeforeToDelete = Integer.parseInt(SDF.format(calendar.getTime()));
		System.out.println("Deleting Folders Before Data = " + dateBeforeToDelete);
		clean("FOLDER_NAME", dateBeforeToDelete);

	}

}
