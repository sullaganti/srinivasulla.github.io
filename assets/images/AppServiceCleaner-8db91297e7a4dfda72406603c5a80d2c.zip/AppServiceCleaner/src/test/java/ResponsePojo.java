import lombok.Data;

@Data
public class ResponsePojo {
	private String crtime;
	private String path;
	private int size;
	private String mime;
	private String name;
	private String href;
	private String mtime;
}
