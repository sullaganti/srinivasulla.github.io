const fs = require('fs');

// Get the command-line arguments
const reportTitle = process.argv[2];
const detailsURL = process.argv[3];

// Read the contents of the summary.json file
fs.readFile('allure-report/widgets/summary.json', 'utf8', (err, data) => {
  if (err) {
    console.error(err);
    return;
  }

  try {
    const summary = JSON.parse(data);
    const duration = formatDuration(summary.time.duration); // Convert duration to hours and minutes
    const htmlContent = generateHTML(summary, reportTitle, detailsURL,duration);
    fs.writeFile('test_report.html', htmlContent, (err) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log('HTML report generated successfully!');
    });
  } catch (err) {
    console.error('Failed to parse summary.json:', err);
  }
});

function formatDuration(duration) {
  const hours = Math.floor(duration / 3600000);
  const minutes = Math.floor((duration % 3600000) / 60000);
  return `${hours}h ${minutes}m`;
}

function generateHTML(summary, reportTitle, detailsURL,duration) {
  const total = summary.statistic.total;
  const passed = summary.statistic.passed;
  const failed = summary.statistic.failed;
  const skipped = summary.statistic.skipped;
  const broken = summary.statistic.broken;
  
  const passedColor = '#00CC00';
  const failedColor = '#FF0000';
  const skippedColor = '#0066FF';
  const brokenColor = '#FF6600';

  const htmlContent = `<!DOCTYPE html>
  <html>
  <head>
      <style>
          body {
              text-align: center;
              font-family: Arial, sans-serif;
              background-color: #F5F5F5;
              margin: 0;
              padding: 30px;
          }
          
          h1 {
              color: #333333;
          }
          
          table {
              margin: 0 auto;
              border-collapse: collapse;
              width: 400px;
              margin-bottom: 30px;
          }
          
          th, td {
              padding: 10px;
              text-align: center;
              border: 1px solid #333333;
          }
          
          th {
              background-color: #CCCCCC;
          }
          
          td.passed {
              background-color: ${passedColor};
              color: #FFFFFF;
          }
          
          td.failed {
              background-color: ${failedColor};
              color: #FFFFFF;
          }
          
          td.skipped {
              background-color: ${skippedColor};
              color: #FFFFFF;
          }
          
          td.broken {
              background-color: ${brokenColor};
              color: #FFFFFF;
          }
          
          p {
              margin: 5px;
          }
          
          a {
              display: block;
              color: #333333;
              margin-top: 20px;
              text-decoration: none;
              font-weight: bold;
          }
          
          a:hover {
              text-decoration: underline;
          }
      </style>
  </head>
  <body>
      <h1>${reportTitle}</h1>
      
      <table>
          <tr>
              <th>Category</th>
              <th>Count</th>
          </tr>
          <tr>
              <td class="passed">Passed</td>
              <td>${passed}</td>
          </tr>
          <tr>
              <td class="failed">Failed</td>
              <td>${failed}</td>
          </tr>
          <tr>
              <td class="skipped">Skipped</td>
              <td>${skipped}</td>
          </tr>
          <tr>
              <td class="broken">Broken</td>
              <td>${broken}</td>
          </tr>
          <tr>
              <td>Total</td>
              <td>${total}</td>
          </tr>
          <tr>
              <td>Duration</td>
              <td>${duration}</td>
          </tr>
      </table>
      
      <a href="${detailsURL}">Click Here To See The Report</a>
  </body>
  </html>`;

  return htmlContent;
}
